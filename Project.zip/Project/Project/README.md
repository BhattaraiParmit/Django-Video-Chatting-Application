# Study-Buddy
Study Buddy is an E-Learning Application based on Learning Management System (LMS). 
It provides video calling feature, enables chat feature, create room able to communicate with roommate
Login Logout and signup features
video managementfeature
